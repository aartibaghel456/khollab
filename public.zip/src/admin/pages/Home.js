const Home =() =>{
    return(
        <>
        <div className="banner">
            <img src="/assets/image/coming soon.jpeg" alt="checkinout" className="img-responsive"/>
        </div>
        </>
    )
}

export default Home;